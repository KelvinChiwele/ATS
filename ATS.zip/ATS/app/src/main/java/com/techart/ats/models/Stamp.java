package com.techart.ats.models;

/**
 * Created by Kelvin on 05/06/2017.
 */

public class Stamp {
    private Long timeCreated;

    public Stamp() {
    }


    public Long getTimeCreated() {
        return timeCreated;
    }

    public void setTimeCreated(Long timeCreated) {
        this.timeCreated = timeCreated;
    }
}
