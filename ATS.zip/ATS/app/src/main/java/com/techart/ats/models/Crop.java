package com.techart.ats.models;

/**
 * Created by Kelvin on 08/08/2017.
 */

public class Crop {
    private String crop;

    public Crop() {
    }

    public String getCrop() {
        return crop;
    }

    public void setCrop(String crop) {
        this.crop = crop;
    }

}
